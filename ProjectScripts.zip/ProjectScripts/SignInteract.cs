using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SignInteract : MonoBehaviour
{
    public Camera cam;
    public GameObject[] panels;

    void Start()
    {
        cam = Camera.main;
        foreach (GameObject go in panels)
        {
            go.SetActive(false);
        }

    }

    void Update()
    {
        RaycastHit hit;
        float rayDistance = 100f;
        Ray ray = new Ray(cam.transform.position, cam.transform.forward);
        Debug.DrawRay(cam.transform.position, cam.transform.forward);
        if (Physics.Raycast(ray, out hit, Mathf.Infinity))
        {
            if (hit.collider.tag == "Mountain")
            {
                OnButtonPress(0);
            }
            else if (hit.collider.tag == "Plateau")
            {
                OnButtonPress(1);
            }
            else if (hit.collider.tag == "Forest")
            {
                OnButtonPress(2);
            }
            else if (hit.collider.tag == "Volcano")
            {
                OnButtonPress(3);
            }
            else if (hit.collider.tag == "Canyon")
            {
                OnButtonPress(4);
            }
            else if (hit.collider.tag == "Lake")
            {
                OnButtonPress(5);
            }
            else if (hit.collider.tag == "Swamp")
            {
                OnButtonPress(6);
            }
            else
            {
                OnButtonRel();
                Debug.Log("no obj");
            }
        }
    }

    void OnButtonPress(int number)
    {
        panels[number].gameObject.SetActive(true);
    }

    void OnButtonRel()
    {
        foreach (GameObject go in panels)
        {
            go.SetActive(false);
        }
    }
}
