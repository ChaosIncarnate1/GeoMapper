using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class GPTButtons : MonoBehaviour
{
    public GameObject inputField;
    public GameObject outputField;
    public bool fakeIt;
    public TextMeshProUGUI fakedText;
    // Start is called before the first frame update
    public void GPTOnClick()
    {
        if (inputField.activeSelf == false)
        {
            inputField.SetActive(true);
            outputField.SetActive(true);
        }
        else
        {
            inputField.SetActive(false);
            outputField.SetActive(false);
        }
    }
}
