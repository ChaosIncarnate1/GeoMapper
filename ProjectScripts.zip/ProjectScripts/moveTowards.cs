using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveTowards : MonoBehaviour {

    public GameObject objectToMove;
    public GameObject player;
    public float speed;
    public float offset;

    // Start is called before the first frame 
    void Start() {
        
    }

    // Update is called once per frame
    void Update() {
        float distance = Vector3.Distance(objectToMove.transform.position, player.transform.position);

        if (distance > offset) {
            objectToMove.transform.position = Vector3.MoveTowards(objectToMove.transform.position, player.transform.position, speed * Time.deltaTime);
        }
    }
}
