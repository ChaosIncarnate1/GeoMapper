using System.Collections;
using System.IO;
using UnityEngine;

public class FilePickerScript : MonoBehaviour
{
    public string finalPath;

    public void LoadFile()
    {
        string[] allowedFileTypes;

        allowedFileTypes = new string[] { "*/*" };

        NativeFilePicker.Permission permission = NativeFilePicker.PickFile((path) =>
        {
            if (path == null)
            {
                Debug.Log("Woops.");
            }
            else
            {
                finalPath = path;
                Debug.Log("Picked File: " + finalPath);
            }
        }, allowedFileTypes);
    }

    public void SaveFile()
    {
        string filePathDummy = Path.Combine(Application.temporaryCachePath, "test.txt");
        File.WriteAllText(filePathDummy, "HelloWorld");
        NativeFilePicker.Permission permission = NativeFilePicker.ExportFile(filePathDummy, (success) => Debug.Log("File Exported: " + success));
    }
}
