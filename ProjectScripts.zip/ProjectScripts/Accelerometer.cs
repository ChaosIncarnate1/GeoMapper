using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Accelerometer : MonoBehaviour
{
    public Rigidbody rigidbody;
    public bool isFlat = true;
    void Update()
    {
        Vector3 tilt = Input.acceleration;
        rigidbody.AddForce(Input.acceleration);
        if (isFlat == true)
        {
            tilt = Quaternion.Euler(90 , 0 , 0) * tilt;
        }
        rigidbody.AddForce(tilt);
        Debug.DrawRay(transform.position + Vector3.up, tilt, Color.cyan);
    }
}
